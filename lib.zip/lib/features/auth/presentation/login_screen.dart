import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nurseos_v3/features/auth/models/user_model.dart';
import 'package:nurseos_v3/core/models/user_role.dart';
import 'package:nurseos_v3/features/auth/state/auth_controller.dart';

class LoginScreen extends ConsumerWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    final authState = ref.watch(authControllerProvider);

    ref.listen<AsyncValue<UserModel?>>(
      authControllerProvider,
      (previous, next) {
        next.whenOrNull(
          data: (user) {
            if (user == null) {
              debugPrint('⚠️ Login failed or user null');
              return;
            }

            final route = user.role == UserRole.admin ? '/admin' : '/patients';
            debugPrint('✅ Login → ${user.email}, role=${user.role.name}');
            Navigator.pushReplacementNamed(context, route);
          },
          error: (e, _) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Login failed: $e')),
            );
          },
        );
      },
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            const SizedBox(height: 24),
            authState.isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: () {
                      final email = emailController.text.trim();
                      final password = passwordController.text.trim();
                      ref
                          .read(authControllerProvider.notifier)
                          .signIn(email, password);
                    },
                    child: const Text('Log in'),
                  ),
          ],
        ),
      ),
    );
  }
}
