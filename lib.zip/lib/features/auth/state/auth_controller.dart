import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nurseos_v3/features/auth/models/user_model.dart';
import 'package:nurseos_v3/features/auth/services/auth_service_provider.dart';

/// AuthController manages authentication state for [UserModel?].
/// It uses Riverpod's [AsyncNotifier] to manage async flows safely.
class AuthController extends AsyncNotifier<UserModel?> {
  /// Initializes the controller by attempting to load the current user
  @override
  Future<UserModel?> build() async {
    final authService = ref.read(authServiceProvider);
    return await authService.getCurrentUser();
  }

  /// Attempts sign-in and updates state accordingly
  Future<void> signIn(String email, String password) async {
    state = const AsyncValue.loading();

    state = await AsyncValue.guard(() async {
      final authService = ref.read(authServiceProvider);
      return await authService.signIn(email, password);
    });
  }

  /// Signs out the user and sets state to null
  Future<void> signOut() async {
    final authService = ref.read(authServiceProvider);
    await authService.signOut();
    state = const AsyncValue.data(null);
  }
}

/// Global provider for accessing [AuthController] as an [AsyncNotifierProvider].
final authControllerProvider =
    AsyncNotifierProvider<AuthController, UserModel?>(
  AuthController.new,
);
