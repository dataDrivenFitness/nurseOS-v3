// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'font_scale_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$fontScaleStreamHash() => r'0bc0079ff1db630976f84701204cd41124f6a9a5';

/// 🆕 Live Firestore stream → UI reacts instantly.
///
/// Copied from [fontScaleStream].
@ProviderFor(fontScaleStream)
final fontScaleStreamProvider = StreamProvider<double>.internal(
  fontScaleStream,
  name: r'fontScaleStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$fontScaleStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef FontScaleStreamRef = StreamProviderRef<double>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
