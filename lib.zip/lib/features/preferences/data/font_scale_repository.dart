// 📁 lib/features/preferences/data/font_scale_repository.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nurseos_v3/core/env/env.dart';
import 'package:nurseos_v3/core/providers/shared_prefs_provider.dart'; // ✅ single source

/* ──────────────────────────────────────────────────────────────
   Abstraction
─────────────────────────────────────────────────────────────── */
abstract class AbstractFontScaleRepository {
  Future<double?> getFontScale(String uid);
  Future<void> setFontScale(String uid, double scale);
}

/* ──────────────────────────────────────────────────────────────
   Firebase + SharedPreferences implementation
─────────────────────────────────────────────────────────────── */
class FirebaseFontScaleRepository implements AbstractFontScaleRepository {
  FirebaseFontScaleRepository(this._prefs, this._firestore);

  final SharedPreferences _prefs;
  final FirebaseFirestore _firestore;

  static const _prefsKey = 'font_scale';

  @override
  Future<double?> getFontScale(String uid) async {
    debugPrint('📥 getFontScale uid=$uid');

    if (uid.isEmpty) throw ArgumentError('UID required for getFontScale');

    // 1️⃣ Local cache
    final local = _prefs.getDouble(_prefsKey);
    if (local != null) return local;

    // 2️⃣ Firestore fallback
    final doc = await _firestore.doc('users/$uid/preferences/global').get();
    final remote = doc.data()?['font_scale'];

    if (remote is num) {
      final scale = remote.toDouble();
      await _prefs.setDouble(_prefsKey, scale);
      return scale;
    }

    return null;
  }

  @override
  Future<void> setFontScale(String uid, double scale) async {
    if (uid.isEmpty) throw ArgumentError('UID required for setFontScale');

    await _prefs.setDouble(_prefsKey, scale); // local
    await _firestore
        .doc('users/$uid/preferences/global')
        .set({'font_scale': scale}, SetOptions(merge: true)); // remote
  }
}

/* ──────────────────────────────────────────────────────────────
   Provider
─────────────────────────────────────────────────────────────── */
final fontScaleRepositoryProvider =
    Provider<AbstractFontScaleRepository>((ref) {
  if (useMockServices) {
    throw UnimplementedError('MockFontScaleRepository not implemented');
  }

  // 🔹 Global sharedPrefsProvider now used everywhere
  final prefs = ref.watch(sharedPreferencesProvider);
  final firestore = FirebaseFirestore.instance;

  return FirebaseFontScaleRepository(prefs, firestore);
});
